package Bespoke.BespokeBids;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BespokeBidsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BespokeBidsApplication.class, args);
	}

}
